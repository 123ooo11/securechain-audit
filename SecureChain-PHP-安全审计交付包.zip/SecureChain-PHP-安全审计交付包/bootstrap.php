<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function db(): PDO { static $pdo = null; if ($pdo instanceof PDO) return $pdo; $pdo = new PDO('mysql:host='.DB_HOST.';port='.DB_PORT.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); return $pdo; }
function h(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
function now_text(): string { return date('Y-m-d H:i:s'); }
function logged_in(): bool { return isset($_SESSION['user_id']); }
function require_login(): void { if (!logged_in()) { header('Location: login.php'); exit; } }
function is_admin(): bool { return ($_SESSION['role'] ?? '') === 'admin'; }
function require_admin(): void { require_login(); if (!is_admin()) { http_response_code(403); exit('Forbidden'); } }
function audit(string $action, string $outcome='success', string $details=''): void { try { $s=db()->prepare('INSERT INTO audit_logs(created_at,username,ip,method,path,action,outcome,details) VALUES (?,?,?,?,?,?,?,?)'); $s->execute([now_text(),$_SESSION['username']??'anonymous',$_SERVER['REMOTE_ADDR']??'unknown',$_SERVER['REQUEST_METHOD']??'GET',$_SERVER['REQUEST_URI']??'/', $action,$outcome,substr($details,0,500)]); } catch (Throwable $e) {} }
function flash_msg(string $message): void { $_SESSION['flash']=$message; }
function show_flash(): void { if(isset($_SESSION['flash'])) { echo '<div class="flash">'.h($_SESSION['flash']).'</div>'; unset($_SESSION['flash']); } }
function page_start(string $title): void { $label=APP_MODE==='fixed'?'Hardened environment':'Assessment environment'; echo '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.h($title).' | '.APP_NAME.'</title><link rel="stylesheet" href="style.css"></head><body><header><a class="brand" href="dashboard.php"><b>LH</b><span><strong>Lanhai SecureChain</strong><small>Pharmaceutical supply-chain collaboration</small></span></a><div class="top-meta"><span class="mode '.APP_MODE.'">'.h($label).'</span>'; if(logged_in()) echo '<span>'.h($_SESSION['display_name']).'</span><a href="logout.php">退出</a>'; echo '</div></header>'; if(logged_in()) echo '<div class="shell"><nav><a href="dashboard.php">总览</a><a href="suppliers.php">供应商准入</a><a href="notices.php">合规公告</a><a href="documents.php">合规文档</a><a href="xml_import.php">批次 XML 导入</a>'.(is_admin()?'<span>管理中心</span><a href="audit.php">审计日志</a>':'').'</nav><main>'; else echo '<main class="public">'; }
function page_end(): void { echo '</main></div></body></html>'; }

