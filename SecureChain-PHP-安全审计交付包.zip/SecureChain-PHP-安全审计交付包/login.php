<?php
require_once __DIR__ . '/bootstrap.php';

if (logged_in()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $s = db()->prepare('SELECT * FROM users WHERE username=?');
    $s->execute([trim($_POST['username'] ?? '')]);
    $u = $s->fetch();

    if ($u && hash_equals($u['password_hash'], hash('sha256', $_POST['password'] ?? ''))) {
        session_regenerate_id(true);
        $_SESSION = [
            'user_id' => $u['id'],
            'username' => $u['username'],
            'display_name' => $u['display_name'],
            'role' => $u['role'],
        ];
        audit('login');
        header('Location: dashboard.php');
        exit;
    }

    audit('login', 'failure', 'invalid credentials');
    $error = '用户名或密码不正确。';
}

page_start('登录');
?>
<section class="login">
    <div>
        <p class="eyebrow">CONTROL TOWER</p>
        <h1>澜海医药供应链安全协同平台</h1>
        <p>连接供应商准入、质量合规、批次追踪与内部安全运营。</p>
    </div>
    <form class="panel" method="post">
        <h2>平台登录</h2>
        <label>
            用户名
            <input name="username" required>
        </label>
        <label>
            密码
            <input type="password" name="password" required>
        </label>
        <button>登录</button>
        <?php if ($error): ?>
            <p class="error"><?= h($error) ?></p>
        <?php endif; ?>
    </form>
</section>
<?php
page_end();
