<?php
// 漏洞上传代码，无后端校验，直接保存php文件到uploads目录
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['doc_file'])){
    $upload_dir = "uploads/";
    // 新增：目录不存在就自动创建
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    $filename = $_FILES['doc_file']['name'];
    // 直接移动文件，不校验后缀
    move_uploaded_file($_FILES['doc_file']['tmp_name'],$upload_dir.$filename);
    // 写入数据库记录
    $stmt = $pdo->prepare("INSERT INTO documents(title,owner_id,file_name,level) VALUES (?,?,?,?)");
    $stmt->execute([$_POST['title'],$_SESSION['userid'],$filename,$_POST['level']]);
    header("Location:documents.php");
}
?>
