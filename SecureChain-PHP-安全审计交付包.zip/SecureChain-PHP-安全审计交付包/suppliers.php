<?php
require_once __DIR__ . '/bootstrap.php';
require_login();

$q = trim($_GET['q'] ?? '');

if ($q !== '' && APP_MODE === 'vulnerable') {
    // === 漏洞模式：直接拼接 SQL ===
    $sql = "SELECT * FROM suppliers WHERE name LIKE '%$q%' OR supplier_code LIKE '%$q%' OR region LIKE '%$q%'";
    try {
        $rows = db()->query($sql)->fetchAll();
        audit('supplier_search', 'success', 'raw query=' . $q);
    } catch (Throwable $e) {
        $rows = [];
        audit('supplier_search', 'failure', $e->getMessage());
    }
} elseif ($q !== '') {
    // === 修复模式：参数化查询 ===
    $s = db()->prepare('SELECT * FROM suppliers WHERE name LIKE ? OR supplier_code LIKE ? OR region LIKE ?');
    $p = '%' . $q . '%';
    $s->execute([$p, $p, $p]);
    $rows = $s->fetchAll();
    audit('supplier_search', 'success', 'parameterized');
} else {
    $rows = db()->query('SELECT * FROM suppliers ORDER BY id')->fetchAll();
}

page_start('供应商准入');
?>
<div class="heading">
    <div>
        <p class="eyebrow">SUPPLIER DUE DILIGENCE</p>
        <h1>供应商准入档案</h1>
    </div>
</div>
<form class="toolbar">
    <input name="q" value="<?= h($q) ?>" placeholder="搜索名称、编号或地区">
    <button>查询</button>
</form>
<div class="table-wrap">
    <table>
        <tr>
            <th>编号</th>
            <th>供应商</th>
            <th>地区</th>
            <th>资质状态</th>
            <th>风险等级</th>
        </tr>
        <?php foreach ($rows as $r): ?>
        <tr>
            <td><?= h($r['supplier_code']) ?></td>
            <td><?= h($r['name']) ?></td>
            <td><?= h($r['region']) ?></td>
            <td><?= h($r['qualification_status']) ?></td>
            <td><?= h($r['risk_level']) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
<?php
page_end();
