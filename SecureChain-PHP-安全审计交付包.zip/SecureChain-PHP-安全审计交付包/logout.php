<?php require_once __DIR__.'/bootstrap.php'; if(logged_in()) audit('logout'); session_destroy(); header('Location: login.php'); exit;

