# 澜海医药供应链安全协同平台

本项目是仅供本机授权练习使用的 PHP + MySQL Web 安全评估项目。

项目模拟医药供应链企业的供应商准入、合规公告、合规文档、合作方批次 XML 导入和安全审计流程。提供 `vulnerable` 和 `fixed` 两种模式，用于漏洞验证与修复复测。

漏洞类型：SQL 注入、存储型 XSS、XXE、对象级授权缺失（文档越权）。

本地练习账号的密码使用 SHA-256 做初始化校验，仅用于靶场演示；真实生产系统应使用 PHP `password_hash()` 和 `password_verify()`。

部署说明见 `docs/DEPLOY_STEP_BY_STEP.md`。
