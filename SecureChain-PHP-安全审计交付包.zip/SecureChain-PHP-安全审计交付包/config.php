<?php
declare(strict_types=1);
define('APP_NAME', 'Lanhai SecureChain');
define('APP_MODE', 'vulnerable');
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'securechain_vuln');
define('DB_USER', 'root');
define('DB_PASS', 'root123');
define('UPLOAD_DIR', __DIR__ . DIRECTORY_SEPARATOR . 'uploads');
date_default_timezone_set('Asia/Shanghai');

