<?php require_once __DIR__.'/bootstrap.php'; header('Location: '.(logged_in()?'dashboard.php':'login.php')); exit;

